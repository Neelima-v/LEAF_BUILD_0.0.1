age=20
if age>18:
age=age+12
print=1
 
 age2=200
 print(age)
