from django.db import models


class SignupData(models.Model):
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    user_id = models.CharField(max_length=20)
    email = models.EmailField()
    contact_number = models.IntegerField()
    password = models.CharField(max_length=20)


